import { GoogleGenAI } from "@google/genai";
import { LegalSection } from "../types";

// Initialize Gemini Client
// IMPORTANT: In a real app, ensure API keys are secured via backend proxy or strictly controlled env vars.
// For this demo, we assume process.env.API_KEY is available.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateLegalAdvice = async (
  scenario: string,
  retrievedContext: LegalSection[]
): Promise<string> => {
  
  // 1. Construct the RAG Prompt
  // We feed the "Retrieved" sections as ground truth context.
  
  const contextText = retrievedContext.map(s => 
    `ACT: ${s.act}
     SECTION: ${s.section}
     TITLE: ${s.title}
     DEFINITION: ${s.description}
     PUNISHMENT: ${s.punishment || "Not specified in snippet"}`
  ).join("\n\n");

  const prompt = `
    You are a highly capable Legal Assistant specialized in Indian Law.
    
    TASK: Analyze the following user scenario based *primarily* on the provided LEGAL CONTEXT (Bare Acts).
    
    LEGAL CONTEXT (Retrieved from Database):
    ${contextText ? contextText : "No specific IPC sections were found in the local database matching this exact query. Use general knowledge of Indian Law."}
    
    USER SCENARIO:
    "${scenario}"
    
    INSTRUCTIONS:
    1. Identify the potential offenses based on the scenario.
    2. Cite the specific sections from the provided LEGAL CONTEXT if applicable.
    3. Explain *why* the scenario fits the legal definition.
    4. Mention potential punishments.
    5. Provide a Disclaimer: "This is AI-generated information for educational purposes, not professional legal advice."
    
    Format the response in clear Markdown. Use bolding for Sections and Penalties.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.3, // Low temperature for factual consistency
      }
    });

    return response.text || "Unable to generate a response.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I encountered an error while processing your request. Please check your network or API key.";
  }
};
