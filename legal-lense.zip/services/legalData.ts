import { LegalSection } from '../types';

// In a real production app, this would be a vector database (ChromaDB) accessed via backend.
// For this frontend-only demo, we use a curated list of common IPC sections.

export const MOCK_IPC_DATABASE: LegalSection[] = [
  {
    id: "IPC_378",
    act: "Indian Penal Code",
    section: "378",
    title: "Theft",
    description: "Whoever, intending to take dishonestly any movable property out of the possession of any person without that person's consent, moves that property in order to such taking, is said to commit theft.",
    punishment: "Imprisonment of up to 3 years, or fine, or both.",
    keywords: ["steal", "theft", "property", "move", "possession", "dishonest", "robbery", "taking"]
  },
  {
    id: "IPC_420",
    act: "Indian Penal Code",
    section: "420",
    title: "Cheating and dishonestly inducing delivery of property",
    description: "Whoever cheats and thereby dishonestly induces the person deceived to deliver any property to any person, or to make, alter or destroy the whole or any part of a valuable security...",
    punishment: "Imprisonment of up to 7 years and fine.",
    keywords: ["cheat", "fraud", "scam", "deceive", "money", "delivery", "induce", "420"]
  },
  {
    id: "IPC_300",
    act: "Indian Penal Code",
    section: "300",
    title: "Murder",
    description: "Culpable homicide is murder, if the act by which the death is caused is done with the intention of causing death...",
    punishment: "Death or imprisonment for life, and fine.",
    keywords: ["murder", "kill", "death", "homicide", "intention", "fatal"]
  },
  {
    id: "IPC_304A",
    act: "Indian Penal Code",
    section: "304A",
    title: "Causing death by negligence",
    description: "Whoever causes the death of any person by doing any rash or negligent act not amounting to culpable homicide.",
    punishment: "Imprisonment of up to 2 years, or fine, or both.",
    keywords: ["accident", "negligence", "rash", "driving", "car crash", "mistake", "death"]
  },
  {
    id: "IPC_499",
    act: "Indian Penal Code",
    section: "499",
    title: "Defamation",
    description: "Whoever, by words either spoken or intended to be read, or by signs or by visible representations, makes or publishes any imputation concerning any person intending to harm...",
    punishment: "Simple imprisonment of up to 2 years, or fine, or both.",
    keywords: ["defamation", "slander", "libel", "reputation", "insult", "rumor", "lie"]
  },
  {
    id: "IPC_425",
    act: "Indian Penal Code",
    section: "425",
    title: "Mischief",
    description: "Whoever with intent to cause, or knowing that he is likely to cause, wrongful loss or damage to the public or to any person, causes the destruction of any property...",
    punishment: "Imprisonment of up to 3 months, or fine, or both.",
    keywords: ["damage", "destroy", "break", "property", "vandalism", "mischief", "loss", "tree"]
  },
  {
    id: "IPC_441",
    act: "Indian Penal Code",
    section: "441",
    title: "Criminal Trespass",
    description: "Whoever enters into or upon property in the possession of another with intent to commit an offence or to intimidate, insult or annoy any person in possession of such property...",
    punishment: "Imprisonment of up to 3 months, or fine of 500 rupees, or both.",
    keywords: ["trespass", "enter", "property", "land", "house", "intrude", "unauthorized"]
  },
  {
    id: "IPC_351",
    act: "Indian Penal Code",
    section: "351",
    title: "Assault",
    description: "Whoever makes any gesture, or any preparation intending or knowing it to be likely that such gesture or preparation will cause any person present to apprehend that he who makes that gesture or preparation is about to use criminal force to that person...",
    punishment: "Imprisonment of up to 3 months, or fine, or both.",
    keywords: ["assault", "threat", "gesture", "fear", "scare", "attack"]
  },
  {
    id: "IPC_354",
    act: "Indian Penal Code",
    section: "354",
    title: "Assault or criminal force to woman with intent to outrage her modesty",
    description: "Whoever assaults or uses criminal force to any woman, intending to outrage or knowing it to be likely that he will there by outrage her modesty...",
    punishment: "Imprisonment not less than 1 year but up to 5 years, and fine.",
    keywords: ["woman", "modesty", "harassment", "assault", "force", "female"]
  },
  {
    id: "IPC_503",
    act: "Indian Penal Code",
    section: "503",
    title: "Criminal Intimidation",
    description: "Whoever threatens another with any injury to his person, reputation or property, or to the person or reputation of any one in whom that person is interested, with intent to cause alarm to that person...",
    punishment: "Imprisonment of up to 2 years, or fine, or both.",
    keywords: ["threat", "intimidation", "fear", "alarm", "blackmail", "warning"]
  }
];