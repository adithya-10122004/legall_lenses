import { LegalSection } from '../types';
import { MOCK_IPC_DATABASE } from './legalData';

// In a full stack app, this would use TensorFlow.js to generate embeddings for the query
// and query ChromaDB for the nearest neighbors (Cosine Similarity).
// Here, we simulate retrieval using a weighted keyword scoring algorithm to keep it fast and client-side.

export const retrieveRelevantSections = async (query: string): Promise<LegalSection[]> => {
  // Simulate network latency for "Database Query"
  await new Promise(resolve => setTimeout(resolve, 600));

  const normalizedQuery = query.toLowerCase();
  const tokens = normalizedQuery.split(/\s+/).filter(t => t.length > 2); // basic stopwords filter

  const scoredSections = MOCK_IPC_DATABASE.map(section => {
    let score = 0;

    // Check title matches (High weight)
    if (normalizedQuery.includes(section.title.toLowerCase())) {
      score += 10;
    }

    // Check keyword matches (Medium weight)
    section.keywords.forEach(keyword => {
      if (normalizedQuery.includes(keyword)) {
        score += 5;
      }
    });

    // Check exact token matches in description (Low weight)
    tokens.forEach(token => {
      if (section.description.toLowerCase().includes(token)) {
        score += 1;
      }
    });

    return { section, score };
  });

  // Filter out zero scores and sort by relevance
  const topSections = scoredSections
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .map(item => item.section)
    .slice(0, 3); // Top 3 chunks

  return topSections;
};
