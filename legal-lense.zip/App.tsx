import React, { useState, useEffect, useRef } from 'react';
import { LegalHeader } from './components/LegalHeader';
import { ChatBubble } from './components/ChatBubble';
import { RetrievedSectionCard } from './components/RetrievedSectionCard';
import { AuthScreen } from './components/AuthScreen';
import { IPCLibrary } from './components/IPCLibrary';
import { ChatMessage, LegalSection, AppState, User } from './types';
import { retrieveRelevantSections } from './services/ragService';
import { generateLegalAdvice } from './services/geminiService';
import { Send, Book, Scale, Info, Search } from 'lucide-react';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<'chat' | 'library'>('chat');
  
  // Chat State
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentRetrievedSections, setCurrentRetrievedSections] = useState<LegalSection[]>([]);
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Initialize Auth state from LocalStorage
  useEffect(() => {
    const savedUser = localStorage.getItem('legalmind_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  // Initialize Welcome Message
  useEffect(() => {
    if (user && messages.length === 0) {
      setMessages([
        {
          id: 'welcome',
          role: 'assistant',
          content: `### Welcome to Legal Lense, ${user.name}. \n\nI am your specialized AI legal counsel. \n\nPlease describe the legal scenario or facts of the case you wish to analyze. I will cross-reference your input against the Indian Penal Code database to provide grounded insights.`,
          timestamp: Date.now()
        }
      ]);
    }
  }, [user]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (currentView === 'chat') {
      scrollToBottom();
    }
  }, [messages, currentView]);

  const handleLogin = (userData: User) => {
    localStorage.setItem('legalmind_user', JSON.stringify(userData));
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('legalmind_user');
    setUser(null);
    setMessages([]);
    setCurrentRetrievedSections([]);
    setInput('');
    setCurrentView('chat');
  };

  const handleSend = async () => {
    if (!input.trim() || appState !== AppState.IDLE) return;

    const userText = input.trim();
    setInput('');
    // Reset textarea height
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    
    setAppState(AppState.ANALYZING);

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: userText,
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, userMsg]);

    try {
      setAppState(AppState.RETRIEVING);
      
      const thinkingMsgId = 'thinking-' + Date.now();
      setMessages(prev => [...prev, {
        id: thinkingMsgId,
        role: 'assistant',
        content: '',
        timestamp: Date.now(),
        isThinking: true
      }]);

      const retrievedContext = await retrieveRelevantSections(userText);
      setCurrentRetrievedSections(retrievedContext);

      setAppState(AppState.GENERATING);
      const advice = await generateLegalAdvice(userText, retrievedContext);

      setMessages(prev => {
        const filtered = prev.filter(m => m.id !== thinkingMsgId);
        return [...filtered, {
          id: Date.now().toString(),
          role: 'assistant',
          content: advice,
          timestamp: Date.now(),
          retrievedContext: retrievedContext
        }];
      });

    } catch (error) {
      console.error(error);
      setMessages(prev => prev.filter(m => !m.isThinking).concat({
        id: Date.now().toString(),
        role: 'assistant',
        content: "System Error: Unable to access the legal database or AI service. Please try again later.",
        timestamp: Date.now()
      }));
    } finally {
      setAppState(AppState.IDLE);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const adjustTextareaHeight = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 200)}px`;
  };

  if (!user) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  return (
    <div className="flex flex-col h-screen bg-lense-50 overflow-hidden font-sans">
      <LegalHeader 
        user={user} 
        onLogout={handleLogout} 
        currentView={currentView}
        onViewChange={setCurrentView}
      />

      {/* Main Layout - Swaps based on View */}
      {currentView === 'library' ? (
        <IPCLibrary />
      ) : (
        <main className="flex-1 flex max-w-[1920px] mx-auto w-full h-[calc(100vh-64px)]">
          {/* Left Column: Chat Interface */}
          <section className="flex-1 flex flex-col relative bg-white border-r border-gray-200">
            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-200 scrollbar-track-transparent bg-white">
              {messages.map(msg => (
                <ChatBubble key={msg.id} message={msg} />
              ))}
              <div ref={messagesEndRef} className="h-4" />
            </div>

            {/* Input Area */}
            <div className="p-8 bg-white border-t border-gray-100 z-10">
              <div className="max-w-5xl mx-auto">
                <div className="relative shadow-sm rounded-none bg-lense-50 border border-gray-200 focus-within:border-lense-900 transition-all duration-300">
                  <textarea
                    ref={textareaRef}
                    value={input}
                    onChange={adjustTextareaHeight}
                    onKeyDown={handleKeyDown}
                    placeholder="Enter case details for analysis..."
                    className="w-full py-4 pl-5 pr-14 border-none focus:ring-0 resize-none max-h-[200px] min-h-[60px] bg-transparent text-lense-900 placeholder-gray-400 text-base font-serif"
                    disabled={appState !== AppState.IDLE}
                    rows={1}
                  />
                  <div className="absolute right-2 bottom-2">
                    <button
                      onClick={handleSend}
                      disabled={!input.trim() || appState !== AppState.IDLE}
                      className={`p-2 rounded-none transition-all duration-200 flex items-center justify-center ${
                        input.trim() && appState === AppState.IDLE
                          ? 'bg-lense-900 text-white hover:bg-black'
                          : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      }`}
                    >
                      {appState !== AppState.IDLE ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <Send size={18} className={input.trim() ? "ml-0.5" : ""} />
                      )}
                    </button>
                  </div>
                </div>
                <div className="mt-3 text-center">
                  <p className="text-[10px] text-gray-400 font-mono flex items-center justify-center gap-1.5 uppercase tracking-wide">
                    <Info size={10} /> 
                    <span>Generated content is for informational purposes only.</span>
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Right Column: Retrieval Evidence Board */}
          <aside className="hidden xl:flex w-[420px] flex-col bg-lense-50 border-l border-gray-200">
            <div className="p-6 border-b border-gray-200 bg-lense-50 sticky top-0 z-10">
              <div className="flex items-center gap-2 mb-1">
                <Book size={16} className="text-lense-900" />
                <h2 className="text-xs font-bold text-lense-900 uppercase tracking-widest">
                  Evidence Board
                </h2>
              </div>
              <p className="text-[10px] text-gray-500 font-mono mt-1">
                Live Context Retrieval Stream
              </p>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 scrollbar-thin scrollbar-thumb-gray-300">
              {currentRetrievedSections.length > 0 ? (
                <div className="space-y-4 animate-fadeIn">
                  <div className="flex items-center justify-between text-[10px] font-mono text-gray-400 mb-2 px-1 border-b border-gray-200 pb-1">
                      <span>SOURCE: MOCK_IPC_DB</span>
                      <span>STATUS: VERIFIED</span>
                  </div>
                  {currentRetrievedSections.map((section, idx) => (
                    <RetrievedSectionCard key={`${section.id}-${idx}`} section={section} />
                  ))}
                  
                  <div className="mt-8 p-5 bg-lense-900 text-lense-50 rounded-sm shadow-lg">
                    <p className="font-bold text-xs uppercase tracking-widest mb-2 flex items-center gap-2 text-lense-gold">
                      <Scale size={14} /> 
                      RAG System Active
                    </p>
                    <p className="text-xs leading-relaxed opacity-80 font-serif">
                      Response generation is currently grounded in the verified sections provided above. This ensures high factual accuracy and adherence to Indian Penal Code definitions.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-gray-300 opacity-80">
                  <div className="w-16 h-16 border-2 border-dashed border-gray-300 flex items-center justify-center mb-4 rounded-full">
                    <Search size={24} />
                  </div>
                  <p className="text-sm font-serif font-medium text-gray-400">System Ready</p>
                  <p className="text-[10px] font-mono text-center px-8 mt-2 max-w-[250px] leading-relaxed uppercase tracking-wide">
                    Waiting for case input...
                  </p>
                </div>
              )}
            </div>
          </aside>
        </main>
      )}
    </div>
  );
};

export default App;