import React from 'react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage } from '../types';
import { Bot, User, Loader2 } from 'lucide-react';

interface Props {
  message: ChatMessage;
}

export const ChatBubble: React.FC<Props> = ({ message }) => {
  const isUser = message.role === 'user';

  if (message.isThinking) {
    return (
      <div className="flex gap-6 p-8 max-w-5xl mx-auto w-full border-l-2 border-lense-gold/30 bg-lense-50 my-4 animate-pulse">
        <div className="text-xs font-mono text-lense-gold flex items-center gap-2 uppercase tracking-widest">
            <Loader2 className="animate-spin" size={12} />
            Retrieving Legal Precedents...
        </div>
      </div>
    );
  }

  return (
    <div className={`group flex flex-col md:flex-row gap-6 p-8 transition-colors duration-200 border-b border-gray-100 ${isUser ? 'bg-white' : 'bg-lense-50/50'}`}>
      <div className="max-w-5xl mx-auto w-full flex gap-8">
        
        {/* Identifier Column */}
        <div className="w-24 shrink-0 flex flex-col items-end pt-1">
           <span className={`text-xs font-mono font-bold uppercase tracking-wider mb-1 ${isUser ? 'text-gray-400' : 'text-lense-gold'}`}>
             {isUser ? 'QUERY' : 'RESPONSE'}
           </span>
           <span className="text-[10px] text-gray-300 font-mono">
              {new Date(message.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
           </span>
        </div>
        
        {/* Content Column */}
        <div className="flex-1 overflow-hidden">
          <div className={`prose max-w-none 
            ${isUser ? 'text-gray-800' : 'text-lense-900'}
            
            prose-headings:font-serif 
            prose-headings:text-lense-900 
            prose-headings:font-normal
            
            prose-h1:text-2xl prose-h1:border-b prose-h1:border-lense-200 prose-h1:pb-2
            prose-h3:text-lg prose-h3:font-bold prose-h3:text-lense-800 prose-h3:uppercase prose-h3:tracking-wide prose-h3:mt-6
            
            prose-p:leading-8 
            prose-p:mb-4 
            prose-p:font-light
            
            prose-strong:font-bold 
            prose-strong:text-black
            
            prose-ul:list-square prose-ul:pl-4
            
            prose-blockquote:border-l-2 
            prose-blockquote:border-lense-gold 
            prose-blockquote:bg-white 
            prose-blockquote:py-2 
            prose-blockquote:px-6 
            prose-blockquote:not-italic
            prose-blockquote:font-serif
            prose-blockquote:shadow-sm
          `}>
            <ReactMarkdown>{message.content}</ReactMarkdown>
          </div>
        </div>
      </div>
    </div>
  );
};