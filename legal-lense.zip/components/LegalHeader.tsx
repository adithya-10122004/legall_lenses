import React from 'react';
import { Scale, BookOpen, LogOut, User as UserIcon, MessageSquare } from 'lucide-react';
import { User } from '../types';

interface Props {
  user: User | null;
  onLogout: () => void;
  currentView: 'chat' | 'library';
  onViewChange: (view: 'chat' | 'library') => void;
}

export const LegalHeader: React.FC<Props> = ({ user, onLogout, currentView, onViewChange }) => {
  return (
    <header className="bg-lense-900 text-white z-20 sticky top-0 border-b border-lense-800">
      <div className="max-w-[1920px] mx-auto px-6 h-16 flex items-center justify-between">
        
        {/* Brand */}
        <div className="flex items-center gap-12">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => onViewChange('chat')}>
            <div className="w-8 h-8 border border-lense-gold flex items-center justify-center transform group-hover:rotate-45 transition-transform duration-300">
               <Scale className="w-4 h-4 text-lense-gold transform group-hover:-rotate-45 transition-transform duration-300" />
            </div>
            <div className="flex flex-col">
               <h1 className="text-lg font-serif tracking-wide text-white leading-none">Legal Lense</h1>
            </div>
          </div>

          {/* Navigation */}
          {user && (
            <nav className="hidden md:flex items-center gap-1">
              <button
                onClick={() => onViewChange('chat')}
                className={`flex items-center gap-2 px-5 py-2 text-xs font-bold uppercase tracking-widest transition-all border-b-2 ${
                  currentView === 'chat' 
                    ? 'border-lense-gold text-white' 
                    : 'border-transparent text-lense-300 hover:text-white'
                }`}
              >
                Assistant
              </button>
              <button
                onClick={() => onViewChange('library')}
                className={`flex items-center gap-2 px-5 py-2 text-xs font-bold uppercase tracking-widest transition-all border-b-2 ${
                  currentView === 'library' 
                    ? 'border-lense-gold text-white' 
                    : 'border-transparent text-lense-300 hover:text-white'
                }`}
              >
                Library
              </button>
            </nav>
          )}
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-8">
          <div className="hidden lg:flex items-center space-x-2 text-[10px] font-mono text-lense-300">
             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
             <span>SYSTEM ONLINE</span>
          </div>

          {user && (
            <div className="flex items-center gap-6 pl-8 border-l border-lense-800 h-8">
              <div className="flex items-center gap-3 group cursor-pointer">
                 <div className="h-8 w-8 bg-lense-800 flex items-center justify-center text-lense-300 border border-lense-700">
                    {user.profile_picture_url ? (
                    <img src={user.profile_picture_url} alt={user.name} className="h-full w-full object-cover" />
                    ) : (
                    <UserIcon size={14} />
                    )}
                </div>
                <div className="hidden md:flex flex-col">
                    <span className="text-xs font-bold text-white tracking-wide group-hover:text-lense-gold transition-colors">{user.name}</span>
                </div>
              </div>
              <button 
                  onClick={onLogout}
                  className="text-lense-400 hover:text-white transition-colors"
                  title="Logout"
              >
                  <LogOut size={16} />
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};